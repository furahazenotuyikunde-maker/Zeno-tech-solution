'use client';

import React, { useState } from 'react';
import { store } from '@/lib/storage';
import { sound } from '@/lib/sound';
import { UserRole } from '@/types';
import {
  Wifi,
  Unlock,
  Bell,
  Sparkles,
  Volume2,
  Shield,
  Activity,
  CheckCircle2,
  Lock,
} from 'lucide-react';

interface NavbarProps {
  currentRole: UserRole;
  onOpenMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentRole }) => {
  const [showRemoteModal, setShowRemoteModal] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState('204');
  const [unlockMessage, setUnlockMessage] = useState('');

  const handleQuickUnlock = () => {
    sound.playRelayClick();
    setTimeout(() => sound.playDoorUnlock(), 150);
    store.remoteUnlock(selectedRoom);
    setUnlockMessage(`Room ${selectedRoom} strike energized for 4 seconds!`);
    setTimeout(() => {
      setUnlockMessage('');
      setShowRemoteModal(false);
    }, 2500);
  };

  const handleSimulateTap = () => {
    sound.playBeep();
    setTimeout(() => {
      sound.playDoorUnlock();
      store.addLog({
        roomId: 'r-204',
        roomNumber: '204',
        cardUid: 'G-10247',
        guestName: 'John Smith',
        status: 'UNLOCKED',
        reason: 'Direct reader contactless tap',
        source: 'RFID',
      });
    }, 400);
  };

  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 flex items-center justify-between sticky top-0 z-20 shadow-sm">
      {/* Left: System Connectivity & Live Telemetry Badge */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <Wifi className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">AWS MQTT IoT Online</span>
          <span className="text-[10px] text-emerald-500 font-mono">(18ms)</span>
        </div>

        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-500 font-medium">
          <Activity className="w-3.5 h-3.5 text-zeno-teal" />
          <span>Active Door Locks: <strong className="text-slate-800 dark:text-slate-200">11 of 11 Online</strong></span>
        </div>
      </div>

      {/* Right: Quick Actions */}
      <div className="flex items-center gap-3">
        {/* Simulate Card Tap Button */}
        <button
          onClick={handleSimulateTap}
          title="Simulate Card Tap on Room 204"
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5 text-zeno-gold" />
          <span>Tap G-10247 (Rm 204)</span>
        </button>

        {/* Emergency Remote Unlock Button */}
        <button
          onClick={() => setShowRemoteModal(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-heading font-black rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 transition-all shadow-sm"
        >
          <Unlock className="w-3.5 h-3.5" />
          <span>Remote Unlock</span>
        </button>

        {/* User Role Pill */}
        <div className="flex items-center gap-2 pl-3 border-l border-slate-200 dark:border-slate-800">
          <div className="w-8 h-8 rounded-full bg-[#0F1D5E] text-white flex items-center justify-center font-heading font-black text-xs border border-teal-500/30">
            Z
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-bold text-slate-900 dark:text-white capitalize">
              {currentRole}
            </div>
            <div className="text-[9px] text-slate-400 font-mono">Grand Serena</div>
          </div>
        </div>
      </div>

      {/* Remote Unlock Modal */}
      {showRemoteModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 max-w-sm w-full rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-500 flex items-center justify-center mx-auto mb-3">
              <Unlock className="w-6 h-6" />
            </div>

            <h3 className="font-heading font-black text-lg text-slate-900 dark:text-white">
              Cloud Emergency Unlock
            </h3>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Send authenticated MQTT command to ESP32 strike lock over TLS
            </p>

            <div className="mb-4 text-left">
              <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-400 mb-1">
                Select Room Door:
              </label>
              <select
                value={selectedRoom}
                onChange={(e) => setSelectedRoom(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {['101', '102', '103', '104', '201', '202', '203', '204', '205', '301', '302'].map(
                  (rm) => (
                    <option key={rm} value={rm}>
                      Room {rm}
                    </option>
                  )
                )}
              </select>
            </div>

            {unlockMessage ? (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 animate-pulse">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                {unlockMessage}
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowRemoteModal(false)}
                  className="flex-1 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleQuickUnlock}
                  className="flex-1 py-2 text-xs font-heading font-black uppercase tracking-wider rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-md"
                >
                  Send Unlock Signal
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
