'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { Navbar } from './Navbar';
import { store } from '@/lib/storage';
import { UserRole, Language } from '@/types';

export const DashboardLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRole] = useState<UserRole>('admin');
  const [lang, setLang] = useState<Language>('en');

  useEffect(() => {
    const update = () => {
      setRole(store.getRole());
      setLang(store.getLanguage());
    };
    update();
    const unsub = store.subscribe(update);
    return unsub;
  }, []);

  const handleRoleChange = (newRole: UserRole) => {
    store.setRole(newRole);
  };

  const handleLangChange = (newLang: Language) => {
    store.setLanguage(newLang);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        currentRole={role}
        currentLang={lang}
        onRoleChange={handleRoleChange}
        onLangChange={handleLangChange}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <Navbar currentRole={role} />
        <main className="flex-1 p-6 sm:p-8 max-w-7xl w-full mx-auto space-y-8">
          {children}
        </main>
      </div>
    </div>
  );
};
