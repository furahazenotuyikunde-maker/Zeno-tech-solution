import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/request';

/**
 * ZENO TECH SOLUTION - Paywall & Subscription Enforcement Middleware
 * Protects: /dashboard/:path*, /enroll/:path*, /rooms/:path*, /logs/:path*
 * If hotel subscription is not active AND trial is expired -> Redirects to /billing?expired=true
 */
export function middleware(request: NextRequest) {
  const { pathname, searchParams } = request.nextUrl;

  // Paths protected by subscription paywall
  const protectedPaths = ['/dashboard', '/enroll', '/rooms', '/logs'];
  const isProtected = protectedPaths.some((p) => pathname.startsWith(p));

  if (!isProtected) {
    return NextResponse.next();
  }

  // 1. Check for Subscription State from cookies or query override
  // In a full Supabase environment, read the Supabase session token:
  const authSession = request.cookies.get('sb-access-token')?.value || request.cookies.get('zeno_auth_session')?.value;
  const isDemoSimulation = request.cookies.get('zeno_demo_mode')?.value;

  // Subscription expiration status cookie set by the app or API
  const subStatus = request.cookies.get('zeno_sub_status')?.value; // 'trialing' | 'active' | 'past_due' | 'canceled'
  const trialEndsAtCookie = request.cookies.get('zeno_trial_ends_at')?.value;

  let isExpired = false;

  // Check trial expiration timestamp
  if (subStatus === 'canceled' || subStatus === 'past_due') {
    isExpired = true;
  } else if (subStatus === 'trialing' && trialEndsAtCookie) {
    const trialEndTime = new Date(trialEndsAtCookie).getTime();
    if (!isNaN(trialEndTime) && Date.now() > trialEndTime) {
      isExpired = true;
    }
  }

  // URL query parameter ?sim_expired=true allows instant testing in browser
  if (searchParams.get('sim_expired') === 'true') {
    isExpired = true;
  }

  // If expired, immediately block access and redirect to billing paywall
  if (isExpired) {
    const billingUrl = new URL('/billing', request.url);
    billingUrl.searchParams.set('expired', 'true');
    billingUrl.searchParams.set('reason', subStatus || 'trial_ended');
    return NextResponse.redirect(billingUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/enroll/:path*',
    '/rooms/:path*',
    '/logs/:path*',
  ],
};
