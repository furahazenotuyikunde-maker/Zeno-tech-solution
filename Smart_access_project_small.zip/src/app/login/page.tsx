'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ZenoLogo } from '@/components/brand/ZenoLogo';
import { store } from '@/lib/storage';
import { sound } from '@/lib/sound';
import { UserRole } from '@/types';
import {
  Shield,
  Key,
  Users,
  Wrench,
  ArrowRight,
  Lock,
  Mail,
  Sparkles,
} from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('admin@zenotech.rw');
  const [password, setPassword] = useState('••••••••••••');

  const handleRoleQuickLogin = (role: UserRole) => {
    sound.playBeep();
    store.setRole(role);
    router.push('/dashboard');
  };

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playBeep();
    store.setRole('admin');
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#090E2D] flex flex-col justify-between text-white relative overflow-hidden select-none">
      {/* Decorative background grid and glowing orbs */}
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#0DB5B5 1px, transparent 1px), radial-gradient(#D4A017 1px, transparent 1px)`,
          backgroundSize: '32px 32px',
          backgroundPosition: '0 0, 16px 16px',
        }}
      />
      <div className="absolute top-1/4 -left-48 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-48 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar */}
      <div className="p-6 relative z-10 flex items-center justify-between max-w-7xl mx-auto w-full">
        <ZenoLogo variant="dark" size="sm" showText={true} />
        <span className="text-xs text-slate-400 font-mono">v2.4 IoT Cloud</span>
      </div>

      {/* Middle Login Box */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10">
        <div className="bg-[#0F1D5E]/80 backdrop-blur-xl border border-cyan-500/30 rounded-3xl p-8 sm:p-10 max-w-md w-full shadow-2xl">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-heading font-black text-white">
              ZENO TECH SOLUTION
            </h1>
            <p className="text-xs text-slate-300 mt-1">
              Smart Access Control & Reception Management Portal
            </p>
          </div>

          {/* Quick 1-Click Role Login Selector */}
          <div className="mb-6">
            <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 mb-2 flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Select Fast Role Demo Access:</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleRoleQuickLogin('admin')}
                className="p-3 rounded-xl bg-slate-900/80 border border-slate-700 hover:border-zeno-teal hover:bg-slate-800 transition-all text-center flex flex-col items-center gap-1 group"
              >
                <Shield className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-bold text-white">Admin</span>
                <span className="text-[8px] text-slate-400">Full Owner</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleQuickLogin('receptionist')}
                className="p-3 rounded-xl bg-slate-900/80 border border-slate-700 hover:border-zeno-teal hover:bg-slate-800 transition-all text-center flex flex-col items-center gap-1 group"
              >
                <Key className="w-5 h-5 text-zeno-teal group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-bold text-white">Reception</span>
                <span className="text-[8px] text-slate-400">Enroll Only</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleQuickLogin('technician')}
                className="p-3 rounded-xl bg-slate-900/80 border border-slate-700 hover:border-zeno-teal hover:bg-slate-800 transition-all text-center flex flex-col items-center gap-1 group"
              >
                <Wrench className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-bold text-white">Tech</span>
                <span className="text-[8px] text-slate-400">Hardware</span>
              </button>
            </div>
          </div>

          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-slate-700" />
            <span className="flex-shrink mx-3 text-slate-400 text-[10px] uppercase font-bold tracking-wider">
              Or sign in with email
            </span>
            <div className="flex-grow border-t border-slate-700" />
          </div>

          {/* Standard Form */}
          <form onSubmit={handleCustomLogin} className="space-y-4 mt-2">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-300 mb-1">
                Hotel Staff Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-xl bg-slate-900/90 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-300 mb-1">
                Security Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-xl bg-slate-900/90 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl font-heading font-black text-xs uppercase tracking-wider text-slate-950 bg-gradient-to-r from-zeno-teal to-teal-400 hover:from-teal-400 hover:to-teal-500 shadow-glow transition-all flex items-center justify-center gap-2 mt-2"
            >
              <span>Authenticate Staff</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Footer */}
      <div className="p-6 text-center text-xs text-slate-400 relative z-10">
        © 2026 ZENO TECH SOLUTION • Smart Access Systems • 13.56 MHz RFID / ESP32 Cloud Mesh
      </div>
    </div>
  );
}
