'use client';

import React, { useState } from 'react';
import { ZenoLogo } from '@/components/brand/ZenoLogo';
import { sound } from '@/lib/sound';
import { store } from '@/lib/storage';
import {
  Key,
  Unlock,
  ShieldCheck,
  PhoneCall,
  CheckCircle2,
  Sparkles,
  Wifi,
  Lock,
} from 'lucide-react';

export default function GuestKeyPage({ params }: { params: { id: string } }) {
  const [unlocked, setUnlocked] = useState(false);
  const [unlockedCountdown, setUnlockedCountdown] = useState(0);

  const handleMobileUnlock = () => {
    sound.playRelayClick();
    setTimeout(() => sound.playDoorUnlock(), 150);
    setUnlocked(true);
    setUnlockedCountdown(4);

    store.addLog({
      roomId: 'r-204',
      roomNumber: '204',
      cardUid: 'QR-MOBILE-PASS',
      guestName: 'John Smith (Mobile Key)',
      status: 'UNLOCKED',
      reason: 'Guest smartphone authenticated unlock via ZENO Cloud',
      source: 'QR_BACKUP',
    });

    const interval = setInterval(() => {
      setUnlockedCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setUnlocked(false);
          sound.playRelayClick();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#090E2D] text-white flex flex-col justify-between p-6">
      {/* Brand Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <ZenoLogo variant="dark" size="sm" showText={true} />
        <span className="text-[10px] font-mono bg-zeno-teal/20 text-zeno-teal px-2 py-0.5 rounded border border-zeno-teal/40 font-bold">
          DIGITAL GUEST KEY
        </span>
      </div>

      {/* Main Pass Container */}
      <div className="max-w-sm w-full mx-auto my-auto bg-[#0F1D5E] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl text-center space-y-6">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Grand Serena Hotel & Suites
          </div>
          <h1 className="text-3xl font-heading font-black text-white mt-1">
            ROOM 204
          </h1>
          <div className="text-xs text-zeno-teal font-semibold mt-0.5">
            Guest: JOHN SMITH (VIP Pass)
          </div>
        </div>

        {/* Dynamic Unlock Action Button */}
        <div className="py-2">
          <button
            type="button"
            onClick={handleMobileUnlock}
            disabled={unlocked}
            className={`w-full py-4 rounded-2xl font-heading font-black text-sm uppercase tracking-wider transition-all shadow-xl flex items-center justify-center gap-2 ${
              unlocked
                ? 'bg-emerald-500 text-slate-950 shadow-[0_0_25px_rgba(16,185,129,0.5)]'
                : 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-goldGlow'
            }`}
          >
            {unlocked ? (
              <>
                <Unlock className="w-5 h-5 animate-pulse" />
                <span>Door Unlocked ({unlockedCountdown}s)</span>
              </>
            ) : (
              <>
                <Key className="w-5 h-5" />
                <span>Tap to Unlock Room 204</span>
              </>
            )}
          </button>
        </div>

        {/* QR Code Pass for Optical Door Reader */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col items-center">
          <div className="p-2 bg-white rounded-xl shadow-md">
            <svg width="150" height="150" viewBox="0 0 28 28" fill="#0F1D5E">
              <rect x="2" y="2" width="8" height="8" fill="none" stroke="#0F1D5E" strokeWidth="2" />
              <rect x="4" y="4" width="4" height="4" fill="#0F1D5E" />
              <rect x="18" y="2" width="8" height="8" fill="none" stroke="#0F1D5E" strokeWidth="2" />
              <rect x="20" y="4" width="4" height="4" fill="#0F1D5E" />
              <rect x="2" y="18" width="8" height="8" fill="none" stroke="#0F1D5E" strokeWidth="2" />
              <rect x="4" y="20" width="4" height="4" fill="#0F1D5E" />
              <rect x="12" y="3" width="2" height="6" fill="#0F1D5E" />
              <rect x="12" y="12" width="4" height="4" fill="#0F1D5E" />
              <rect x="3" y="12" width="6" height="2" fill="#0F1D5E" />
              <rect x="18" y="14" width="6" height="2" fill="#0F1D5E" />
              <rect x="14" y="20" width="3" height="5" fill="#0F1D5E" />
              <rect x="20" y="20" width="5" height="5" fill="#0F1D5E" />
            </svg>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-2">
            TOKEN: AUTH-G10247-SEC
          </span>
          <span className="text-[9px] text-slate-500">
            Scan at door optical scanner if RFID card is unavailable
          </span>
        </div>

        {/* Front Desk Call Button */}
        <div className="pt-2">
          <a
            href="tel:+250788123456"
            className="w-full py-2.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
          >
            <PhoneCall className="w-3.5 h-3.5 text-zeno-teal" />
            <span>Call 24/7 Hotel Reception Desk</span>
          </a>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-[10px] text-slate-500">
        Secured by ZENO TECH SOLUTION • Smart Access Systems
      </div>
    </div>
  );
}
