'use client';

import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { store } from '@/lib/storage';
import { sound } from '@/lib/sound';
import { Room } from '@/types';
import {
  DoorClosed,
  Plus,
  Search,
  Filter,
  Unlock,
  BatteryCharging,
  Signal,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Key,
  X,
  Sparkles,
} from 'lucide-react';

export default function RoomsManagementPage() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [floorFilter, setFloorFilter] = useState<number | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'vacant' | 'occupied' | 'maintenance'>('all');
  const [search, setSearch] = useState('');

  // Add Room Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRoomNumber, setNewRoomNumber] = useState('');
  const [newRoomFloor, setNewRoomFloor] = useState(1);
  const [newRoomType, setNewRoomType] = useState<Room['type']>('Standard');

  useEffect(() => {
    const update = () => setRooms(store.getRooms());
    update();
    const unsub = store.subscribe(update);
    return unsub;
  }, []);

  const handleRemoteUnlock = (roomNumber: string) => {
    sound.playRelayClick();
    setTimeout(() => sound.playDoorUnlock(), 150);
    store.remoteUnlock(roomNumber);
    alert(`Room ${roomNumber} door unlocked via cloud command! Strike active for 4 seconds.`);
  };

  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomNumber) return;

    const newRoom: Room = {
      id: `r-${newRoomNumber}`,
      number: newRoomNumber,
      floor: Number(newRoomFloor),
      type: newRoomType,
      status: 'vacant',
      lockId: `ESP32-L${newRoomNumber}`,
      lockStatus: 'online',
      lockBattery: 100,
      lockSignal: -55,
    };

    store.saveRoom(newRoom);
    setShowAddModal(false);
    setNewRoomNumber('');
    sound.playDoorUnlock();
  };

  const filteredRooms = rooms.filter((room) => {
    const matchFloor = floorFilter === 'all' ? true : room.floor === floorFilter;
    const matchStatus = statusFilter === 'all' ? true : room.status === statusFilter;
    const matchSearch =
      room.number.includes(search) ||
      room.type.toLowerCase().includes(search.toLowerCase()) ||
      (room.currentGuest && room.currentGuest.toLowerCase().includes(search.toLowerCase()));
    return matchFloor && matchStatus && matchSearch;
  });

  return (
    <DashboardLayout>
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-black text-slate-900 dark:text-white tracking-tight">
            Rooms & Access Locks Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Configure rooms, map ESP32 wireless lock nodes, and trigger emergency unlocks.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-xl text-xs font-heading font-black uppercase tracking-wider text-white bg-zeno-navy hover:bg-slate-900 border border-teal-500/30 transition-all shadow-md flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-zeno-teal" />
          <span>Add New Room</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Floor tabs */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => setFloorFilter('all')}
              className={`px-3 py-1 rounded-lg ${
                floorFilter === 'all' ? 'bg-white dark:bg-slate-900 text-zeno-teal shadow-sm' : 'text-slate-500'
              }`}
            >
              All Floors
            </button>
            <button
              onClick={() => setFloorFilter(1)}
              className={`px-3 py-1 rounded-lg ${
                floorFilter === 1 ? 'bg-white dark:bg-slate-900 text-zeno-teal shadow-sm' : 'text-slate-500'
              }`}
            >
              Floor 1
            </button>
            <button
              onClick={() => setFloorFilter(2)}
              className={`px-3 py-1 rounded-lg ${
                floorFilter === 2 ? 'bg-white dark:bg-slate-900 text-zeno-teal shadow-sm' : 'text-slate-500'
              }`}
            >
              Floor 2
            </button>
            <button
              onClick={() => setFloorFilter(3)}
              className={`px-3 py-1 rounded-lg ${
                floorFilter === 3 ? 'bg-white dark:bg-slate-900 text-zeno-teal shadow-sm' : 'text-slate-500'
              }`}
            >
              Floor 3
            </button>
          </div>

          {/* Status filter */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold">
            {(['all', 'vacant', 'occupied', 'maintenance'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-lg capitalize ${
                  statusFilter === st ? 'bg-white dark:bg-slate-900 text-zeno-teal shadow-sm' : 'text-slate-500'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search room, type, guest..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal"
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ROOMS GRID */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredRooms.map((room) => {
          const isOccupied = room.status === 'occupied';
          const isMaintenance = room.status === 'maintenance';

          return (
            <div
              key={room.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all p-5 flex flex-col justify-between"
            >
              {/* Card Header */}
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-zeno-navy text-white flex items-center justify-center font-heading font-black text-sm">
                      {room.number}
                    </div>
                    <div>
                      <div className="font-heading font-black text-sm text-slate-900 dark:text-white">
                        Room {room.number}
                      </div>
                      <div className="text-[10px] text-slate-400">Floor {room.floor} • {room.type}</div>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full ${
                      isOccupied
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-300'
                        : isMaintenance
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300'
                        : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300'
                    }`}
                  >
                    {room.status}
                  </span>
                </div>

                {/* Guest / Assignment Info */}
                <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">Guest:</span>
                    <strong className="text-slate-800 dark:text-slate-200 truncate max-w-[140px]">
                      {room.currentGuest || 'No Guest Checked-in'}
                    </strong>
                  </div>

                  {room.cardAssigned && (
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Card UID:</span>
                      <span className="font-mono font-bold text-zeno-teal bg-teal-950/20 px-2 py-0.5 rounded border border-teal-500/20 text-[11px]">
                        {room.cardAssigned}
                      </span>
                    </div>
                  )}

                  {room.lastAccessTime && (
                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Last Tap:
                      </span>
                      <span>{room.lastAccessTime}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Hardware Telemetry & Remote Unlock */}
              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                  <div className="flex items-center gap-1">
                    <BatteryCharging className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{room.lockBattery}%</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Signal className="w-3.5 h-3.5 text-zeno-teal" />
                    <span>{room.lockSignal}dBm</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        room.lockStatus === 'online' ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                    />
                    <span className="capitalize">{room.lockStatus}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleRemoteUnlock(room.number)}
                  className="w-full py-2 rounded-xl text-xs font-heading font-black uppercase tracking-wider text-slate-900 bg-amber-400 hover:bg-amber-500 transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Remote Unlock Strike</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Room Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 max-w-sm w-full rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 relative">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="font-heading font-black text-lg text-slate-900 dark:text-white mb-4">
              Add Hotel Room
            </h3>

            <form onSubmit={handleAddRoom} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Room Number *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 401"
                  value={newRoomNumber}
                  onChange={(e) => setNewRoomNumber(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Floor
                </label>
                <select
                  value={newRoomFloor}
                  onChange={(e) => setNewRoomFloor(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal"
                >
                  <option value={1}>Floor 1</option>
                  <option value={2}>Floor 2</option>
                  <option value={3}>Floor 3</option>
                  <option value={4}>Floor 4</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Room Category
                </label>
                <select
                  value={newRoomType}
                  onChange={(e) => setNewRoomType(e.target.value as Room['type'])}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal"
                >
                  <option value="Standard">Standard</option>
                  <option value="Deluxe">Deluxe</option>
                  <option value="Executive Suite">Executive Suite</option>
                  <option value="Presidential Suite">Presidential Suite</option>
                </select>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 text-xs font-bold rounded-xl border border-slate-300 text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-heading font-black uppercase tracking-wider rounded-xl bg-zeno-teal hover:bg-teal-500 text-slate-950 shadow-md"
                >
                  Save Room
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
