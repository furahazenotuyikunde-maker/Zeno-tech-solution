'use client';

import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { store } from '@/lib/storage';
import { sound } from '@/lib/sound';
import { Room, Guest, AccessLog, CardItem } from '@/types';
import Link from 'next/link';
import {
  DoorClosed,
  CreditCard,
  Wifi,
  Users,
  ShieldAlert,
  ArrowUpRight,
  TrendingUp,
  Activity,
  CheckCircle2,
  XCircle,
  BatteryCharging,
  Signal,
  Download,
  Key,
  Unlock,
  Radio,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

export default function DashboardOverviewPage() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [cards, setCards] = useState<CardItem[]>([]);

  useEffect(() => {
    const update = () => {
      setRooms(store.getRooms());
      setGuests(store.getGuests());
      setLogs(store.getLogs());
      setCards(store.getCards());
    };
    update();
    const unsub = store.subscribe(update);
    return unsub;
  }, []);

  const totalRooms = rooms.length;
  const occupiedRooms = rooms.filter((r) => r.status === 'occupied').length;
  const occupancyRate = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
  const activeCards = cards.filter((c) => c.status === 'active').length;
  const blankCards = cards.filter((c) => c.status === 'unassigned').length;
  const onlineLocks = rooms.filter((r) => r.lockStatus === 'online').length;
  const todayLogs = logs.length;
  const failedAttempts = logs.filter((l) => l.status === 'FAILED').length;

  const handleExportCsv = () => {
    const csvData = store.exportLogsToCsv();
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zeno_access_logs_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSimulateTap = () => {
    sound.playBeep();
    setTimeout(() => {
      sound.playDoorUnlock();
      store.addLog({
        roomId: 'r-204',
        roomNumber: '204',
        cardUid: 'G-10247',
        guestName: 'John Smith',
        status: 'UNLOCKED',
        reason: 'Contactless Mifare 1K door unlock tap',
        source: 'RFID',
      });
    }, 300);
  };

  return (
    <DashboardLayout>
      {/* Top Banner: Hotel Status & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-2 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-black text-slate-900 dark:text-white tracking-tight">
            Hotel Access Telemetry
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time monitoring of ESP32 smart door controllers, RFID credentials, and hotel occupancy.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Link
            href="/dashboard/guests"
            className="px-4 py-2 rounded-xl text-xs font-heading font-black uppercase tracking-wider text-slate-950 bg-zeno-teal hover:bg-teal-400 shadow-glow transition-all flex items-center gap-1.5"
          >
            <Key className="w-3.5 h-3.5" />
            <span>New Enrollment</span>
          </Link>

          <button
            onClick={handleSimulateTap}
            className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-zeno-gold" />
            <span>Tap Card (Room 204)</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4 CORE KPI METRIC CARDS */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Metric 1: Room Occupancy */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Occupancy Rate
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
              <DoorClosed className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-heading font-black text-slate-900 dark:text-white">
                {occupancyRate}%
              </span>
              <span className="text-xs font-semibold text-slate-400">
                ({occupiedRooms}/{totalRooms} Rooms)
              </span>
            </div>
            {/* Progress bar */}
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
              <div
                className="bg-zeno-navy dark:bg-blue-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${occupancyRate}%` }}
              />
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-500 flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-emerald-500" />
            <span>Optimal capacity for weekend check-ins</span>
          </div>
        </div>

        {/* Metric 2: Active Smart Cards */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active Smart Cards
            </span>
            <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-zeno-teal flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-heading font-black text-slate-900 dark:text-white">
                {activeCards}
              </span>
              <span className="text-xs font-bold text-zeno-teal">Issued to Guests</span>
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Blank Mifare Stock: <strong className="text-slate-800 dark:text-slate-200">{blankCards} cards</strong>
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-500 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-zeno-teal" />
            <span>Mifare Classic 1K 13.56MHz encrypted</span>
          </div>
        </div>

        {/* Metric 3: Online ESP32 Locks */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              ESP32 Controllers
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
              <Wifi className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-heading font-black text-emerald-600 dark:text-emerald-400">
                {onlineLocks}/{totalRooms}
              </span>
              <span className="text-xs font-bold text-emerald-600">Online</span>
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Avg Strike Voltage: <strong className="text-slate-800 dark:text-slate-200">12.1V DC</strong>
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-500 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>WebSocket MQTT Stream Connected</span>
          </div>
        </div>

        {/* Metric 4: Failed Access Attempts */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Today's Access Events
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-heading font-black text-slate-900 dark:text-white">
                {todayLogs}
              </span>
              {failedAttempts > 0 && (
                <span className="text-xs font-bold text-rose-500 bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded-full border border-rose-200">
                  {failedAttempts} Denied
                </span>
              )}
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Fail-secure strikes auto-lock within 4s
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-500 flex items-center gap-1">
            <ShieldAlert className="w-3 h-3 text-amber-500" />
            <span>Zero security breaches recorded</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2-COLUMN SECTION: LIVE ACCESS LOG STREAM + HARDWARE LOCK GRID */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left (7 cols): Real-Time Access Event Feed */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-zeno-teal opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-zeno-teal" />
              </span>
              <div>
                <h3 className="font-heading font-black text-base text-slate-900 dark:text-white">
                  Live Door Access Stream
                </h3>
                <p className="text-[11px] text-slate-500">
                  Instant MQTT telemetry from outside room readers
                </p>
              </div>
            </div>

            <Link
              href="/dashboard/logs"
              className="text-xs font-bold text-zeno-teal hover:underline flex items-center gap-1"
            >
              <span>Full History</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Event Stream List */}
          <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[440px] overflow-y-auto">
            {logs.slice(0, 7).map((log) => {
              const isUnlocked = log.status === 'UNLOCKED';
              return (
                <div
                  key={log.id}
                  className="p-4 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        isUnlocked
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200'
                          : 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200'
                      }`}
                    >
                      {isUnlocked ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-black text-sm text-slate-900 dark:text-white">
                          Room {log.roomNumber}
                        </span>
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                            isUnlocked
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}
                        >
                          {log.status}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {log.source}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                        Guest: <strong>{log.guestName}</strong> • Card: <code className="text-zeno-navy font-bold">{log.cardUid}</code>
                      </div>
                      {log.reason && (
                        <div className="text-[11px] text-slate-400 italic mt-0.5">
                          {log.reason}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-[11px] font-mono text-slate-400">
                      {log.timestamp.slice(11, 19)}
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5">
                      {log.timestamp.slice(0, 10)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right (5 cols): Lock Controllers Health & Signal */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-zeno-teal" />
                <h3 className="font-heading font-black text-base text-slate-900 dark:text-white">
                  ESP32 Lock Nodes Status
                </h3>
              </div>
              <Link
                href="/dashboard/rooms"
                className="text-xs font-bold text-zeno-teal hover:underline flex items-center gap-1"
              >
                <span>All Rooms</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {/* Quick Lock Nodes Grid */}
            <div className="space-y-3">
              {rooms.slice(0, 5).map((room) => (
                <div
                  key={room.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-zeno-navy text-white flex items-center justify-center font-heading font-black text-xs">
                      {room.number}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {room.type}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {room.lockId} • {room.currentGuest || 'Vacant'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-right">
                    {/* Battery */}
                    <div className="flex items-center gap-1 text-[11px] font-mono text-slate-500">
                      <BatteryCharging className="w-3.5 h-3.5 text-emerald-500" />
                      <span>{room.lockBattery}%</span>
                    </div>

                    {/* WiFi RSSI */}
                    <div className="flex items-center gap-1 text-[11px] font-mono text-slate-500">
                      <Signal className="w-3.5 h-3.5 text-zeno-teal" />
                      <span>{room.lockSignal}dBm</span>
                    </div>

                    {/* Status Pill */}
                    <span
                      className={`w-2 h-2 rounded-full ${
                        room.lockStatus === 'online'
                          ? 'bg-emerald-500'
                          : room.lockStatus === 'warning'
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controller Quick Link */}
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            <Link
              href="/dashboard/installation"
              className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center justify-center gap-2"
            >
              <Activity className="w-3.5 h-3.5 text-zeno-teal" />
              <span>Open 3-Panel Wiring & ESP32 Firmware</span>
            </Link>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
