'use client';

import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { store } from '@/lib/storage';
import { sound } from '@/lib/sound';
import { AccessLog } from '@/types';
import {
  History,
  Search,
  Filter,
  Download,
  CheckCircle2,
  XCircle,
  Sparkles,
  Calendar,
  ShieldAlert,
  Radio,
  FileSpreadsheet,
} from 'lucide-react';

export default function AccessLogsPage() {
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'UNLOCKED' | 'FAILED'>('all');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'RFID' | 'QR_BACKUP' | 'RECEPTION_REMOTE'>('all');

  useEffect(() => {
    const update = () => setLogs(store.getLogs());
    update();
    const unsub = store.subscribe(update);
    return unsub;
  }, []);

  const handleExportCsv = () => {
    const csv = store.exportLogsToCsv();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zeno_hotel_access_logs_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSimulateFailedTap = () => {
    sound.playError();
    store.addLog({
      roomId: 'r-204',
      roomNumber: '204',
      cardUid: 'G-UNKNOWN-404',
      guestName: 'Unregistered Card',
      status: 'FAILED',
      reason: 'Cryptographic sector key mismatch (Authentication denied)',
      source: 'RFID',
    });
  };

  const filteredLogs = logs.filter((log) => {
    const matchStatus = statusFilter === 'all' ? true : log.status === statusFilter;
    const matchSource = sourceFilter === 'all' ? true : log.source === sourceFilter;
    const matchSearch =
      log.roomNumber.includes(search) ||
      log.cardUid.toLowerCase().includes(search.toLowerCase()) ||
      log.guestName.toLowerCase().includes(search.toLowerCase()) ||
      (log.reason && log.reason.toLowerCase().includes(search.toLowerCase()));
    return matchStatus && matchSource && matchSearch;
  });

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-black text-slate-900 dark:text-white tracking-tight">
            Real-Time Access Logs & Audit Trail
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Complete cryptographic audit trail of all physical card taps, emergency remotes, and QR unlock events.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSimulateFailedTap}
            className="px-3.5 py-2 rounded-xl text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-colors flex items-center gap-1.5"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Simulate Denied Card</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-4 py-2 rounded-xl text-xs font-heading font-black uppercase tracking-wider text-white bg-zeno-navy hover:bg-slate-900 border border-teal-500/30 transition-all shadow-md flex items-center gap-1.5"
          >
            <Download className="w-4 h-4 text-zeno-teal" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Status Tabs */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 rounded-lg ${
                statusFilter === 'all' ? 'bg-white dark:bg-slate-900 text-zeno-teal shadow-sm' : 'text-slate-500'
              }`}
            >
              All Events ({logs.length})
            </button>
            <button
              onClick={() => setStatusFilter('UNLOCKED')}
              className={`px-3 py-1 rounded-lg ${
                statusFilter === 'UNLOCKED' ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-sm' : 'text-slate-500'
              }`}
            >
              Unlocked ({logs.filter((l) => l.status === 'UNLOCKED').length})
            </button>
            <button
              onClick={() => setStatusFilter('FAILED')}
              className={`px-3 py-1 rounded-lg ${
                statusFilter === 'FAILED' ? 'bg-white dark:bg-slate-900 text-rose-600 shadow-sm' : 'text-slate-500'
              }`}
            >
              Failed / Denied ({logs.filter((l) => l.status === 'FAILED').length})
            </button>
          </div>

          {/* Source Filter */}
          <select
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value as typeof sourceFilter)}
            className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200"
          >
            <option value="all">All Channels (RFID, QR, Cloud)</option>
            <option value="RFID">Physical RFID Tap</option>
            <option value="QR_BACKUP">QR Backup Pass</option>
            <option value="RECEPTION_REMOTE">Reception Remote</option>
          </select>
        </div>

        {/* Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search room, guest name, UID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-zeno-teal"
          />
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-4">Timestamp (UTC+2)</th>
                <th className="py-3 px-4">Room Door</th>
                <th className="py-3 px-4">Card UID</th>
                <th className="py-3 px-4">Guest / Bearer</th>
                <th className="py-3 px-4">Channel</th>
                <th className="py-3 px-4">Access Status</th>
                <th className="py-3 px-4">Diagnostic Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No access events found matching your filter.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const isUnlocked = log.status === 'UNLOCKED';
                  return (
                    <tr
                      key={log.id}
                      className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
                    >
                      {/* Timestamp */}
                      <td className="py-3.5 px-4 font-mono text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {log.timestamp}
                      </td>

                      {/* Room */}
                      <td className="py-3.5 px-4 font-heading font-black text-sm text-zeno-navy dark:text-white">
                        Room {log.roomNumber}
                      </td>

                      {/* Card UID */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-zeno-teal border border-slate-200 dark:border-slate-700">
                          {log.cardUid}
                        </span>
                      </td>

                      {/* Guest */}
                      <td className="py-3.5 px-4 font-bold text-slate-800 dark:text-slate-200">
                        {log.guestName}
                      </td>

                      {/* Channel */}
                      <td className="py-3.5 px-4">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {log.source}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wide ${
                            isUnlocked
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}
                        >
                          {isUnlocked ? (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          ) : (
                            <XCircle className="w-3.5 h-3.5" />
                          )}
                          {log.status}
                        </span>
                      </td>

                      {/* Reason / Notes */}
                      <td className="py-3.5 px-4 text-slate-500 italic max-w-xs truncate">
                        {log.reason || 'Authorized entry. Strike released.'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
