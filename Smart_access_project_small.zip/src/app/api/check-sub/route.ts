import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_HOTELS } from '@/lib/storage';

/**
 * ESP32 Hardware Subscription Verification API
 * GET /api/check-sub?hotel_id=xxx&esp32_id=yyy&room=204
 * 
 * Used by ESP32 firmware on boot and before door strike actuation:
 * - If active: { allowed: true, expired: false, ... }
 * - If expired: { allowed: false, expired: true, message: "Blink RED LED 5 times and deny unlock" }
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const hotelId = searchParams.get('hotel_id') || 'h-1';
  const esp32Id = searchParams.get('esp32_id') || 'ESP32-L204';
  const roomNumber = searchParams.get('room') || '204';

  // Find hotel record
  const hotel = INITIAL_HOTELS.find((h) => h.id === hotelId || h.code === hotelId) || INITIAL_HOTELS[0];

  const now = Date.now();
  const trialEnd = new Date(hotel.trialEndsAt).getTime();
  const isTrialActive = hotel.subscriptionStatus === 'trialing' && now <= trialEnd;
  const isPaidActive = hotel.subscriptionStatus === 'active';

  const isAllowed = isPaidActive || isTrialActive;
  const isExpired = !isAllowed;

  const responsePayload = {
    hotel_id: hotel.id,
    hotel_name: hotel.name,
    esp32_id: esp32Id,
    room_number: roomNumber,
    allowed: isAllowed,
    expired: isExpired,
    subscription_status: hotel.subscriptionStatus,
    plan: hotel.plan,
    trial_ends_at: hotel.trialEndsAt,
    max_rooms: hotel.maxRooms,
    timestamp: new Date().toISOString(),
    instruction: isAllowed
      ? 'OK: Unlock door strike for 4 seconds upon authorized card tap'
      : 'DENIED: Subscription expired or canceled. Blink RED LED 5 times. Buzz error 3 times. Strike remains locked.',
  };

  return NextResponse.json(responsePayload, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'no-store, max-age=0',
    },
  });
}
