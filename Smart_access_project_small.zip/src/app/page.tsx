'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ZenoLogo } from '@/components/brand/ZenoLogo';
import { SmartAccessCard } from '@/components/card/SmartAccessCard';
import { InstallationDiagram } from '@/components/hardware/InstallationDiagram';
import { sound } from '@/lib/sound';
import {
  ShieldCheck,
  Zap,
  Wifi,
  Cpu,
  Layers,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Lock,
  Unlock,
  Radio,
  Building,
  CreditCard,
  QrCode,
  Key,
} from 'lucide-react';

export default function MarketingLandingPage() {
  const [heroDoorUnlocked, setHeroDoorUnlocked] = useState(false);

  const handleHeroCardTap = () => {
    sound.playBeep();
    setTimeout(() => {
      sound.playDoorUnlock();
      setHeroDoorUnlocked(true);
      setTimeout(() => {
        sound.playRelayClick();
        setHeroDoorUnlocked(false);
      }, 3500);
    }, 250);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-white select-none">
      {/* ========================================================================= */}
      {/* TOP NAVIGATION BAR */}
      {/* ========================================================================= */}
      <header className="sticky top-0 z-40 bg-[#0F1D5E]/95 backdrop-blur-md border-b border-slate-800 text-white px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/">
            <ZenoLogo variant="dark" size="sm" showText={true} />
          </Link>

          <nav className="hidden md:flex items-center gap-8 text-xs font-bold uppercase tracking-wider text-slate-300">
            <a href="#features" className="hover:text-zeno-teal transition-colors">
              Platform Features
            </a>
            <a href="#card-design" className="hover:text-zeno-teal transition-colors">
              Smart Card Tech
            </a>
            <a href="#architecture" className="hover:text-zeno-teal transition-colors">
              Hardware Architecture
            </a>
            <a href="#pricing" className="hover:text-zeno-teal transition-colors">
              Pricing & ROI
            </a>
          </nav>

          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="text-xs font-bold text-slate-300 hover:text-white px-3 py-2"
            >
              Sign In
            </Link>

            <Link
              href="/dashboard"
              className="px-4 py-2 rounded-xl text-xs font-heading font-black uppercase tracking-wider text-slate-950 bg-gradient-to-r from-zeno-teal to-teal-400 hover:from-teal-300 hover:to-teal-500 shadow-glow transition-all flex items-center gap-1.5"
            >
              <span>Open SaaS Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* HERO SECTION WITH ZENO BLUE CARD & LIVE TAP DEMO */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#0F1D5E] via-[#0D184E] to-[#090E2D] text-white pt-16 pb-24 px-6">
        {/* Subtle holographic grid watermark */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#0DB5B5 1px, transparent 1px), radial-gradient(#D4A017 1px, transparent 1px)`,
            backgroundSize: '32px 32px',
            backgroundPosition: '0 0, 16px 16px',
          }}
        />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          {/* Left: Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zeno-teal/20 text-zeno-teal text-xs font-bold uppercase tracking-wider border border-zeno-teal/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Smart Access Systems for Modern Hospitality</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-black tracking-tight leading-none text-white">
              Intelligent RFID Keycards & ESP32 Wireless Door Controllers.
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Replace fragile mechanical keys with military-grade 13.56 MHz Mifare Classic 1K encryption. Complete with 12V fail-secure strike locks, desk enrollment stations, and sub-second reception cloud telemetry.
            </p>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-3 text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-900/60 rounded-lg border border-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-zeno-teal" /> 12V Fail-Secure NC Strike
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-900/60 rounded-lg border border-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-zeno-teal" /> ESP32 WiFi & Offline SPIFFS
              </span>
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-900/60 rounded-lg border border-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-zeno-teal" /> Instant QR Smartphone Backup
              </span>
            </div>

            {/* CTA Buttons */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <Link
                href="/dashboard"
                className="px-6 py-3.5 rounded-xl text-sm font-heading font-black uppercase tracking-wider text-slate-950 bg-gradient-to-r from-zeno-teal to-teal-400 hover:from-teal-300 hover:to-teal-500 shadow-glow transition-all flex items-center gap-2"
              >
                <span>Launch Live System Demo</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <a
                href="#architecture"
                className="px-6 py-3.5 rounded-xl text-sm font-heading font-bold text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-700 transition-colors flex items-center gap-2"
              >
                <Cpu className="w-4 h-4 text-amber-400" />
                <span>Interactive Hardware Blueprint</span>
              </a>
            </div>
          </div>

          {/* Right: Interactive 3D ZENO Blue Card Visual */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
            <div className="mb-3 flex items-center gap-2 text-xs font-bold text-amber-400 bg-amber-950/40 px-3 py-1 rounded-full border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Interactive Card: Click below or tap on card to test</span>
            </div>

            {/* Smart Access Card Specimen */}
            <SmartAccessCard
              guestName="JOHN SMITH"
              roomNumber="204"
              cardUid="G-10247"
              validUntil="2026-11-04"
              interactive={true}
              onTap={handleHeroCardTap}
            />

            {/* Simulated Live Lock Reaction Box */}
            <div className="mt-6 w-full max-w-sm p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                    heroDoorUnlocked
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {heroDoorUnlocked ? <Unlock className="w-5 h-5 animate-pulse" /> : <Lock className="w-5 h-5" />}
                </div>
                <div>
                  <div className="text-xs font-bold text-white">
                    Room 204 Door Strike Lock
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {heroDoorUnlocked ? (
                      <span className="text-emerald-400 font-bold">12V ENERGIZED • UNLOCKED!</span>
                    ) : (
                      'Fail-Secure Armed (Locked)'
                    )}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleHeroCardTap}
                className="px-3 py-1.5 text-xs font-heading font-black uppercase tracking-wider rounded-xl bg-zeno-teal text-slate-950 hover:bg-teal-400 transition-colors shadow-sm"
              >
                Tap Card
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6 CORE PLATFORM BENEFITS */}
      {/* ========================================================================= */}
      <section id="features" className="py-20 px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs font-bold uppercase tracking-wider text-zeno-teal mb-2">
            Engineered for African & International Hospitality
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-black text-slate-900 dark:text-white">
            Everything your hotel front desk and engineering team needs.
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            A cohesive smart access platform designed to withstand power fluctuations, eliminate card replacement costs, and ensure 100% guest satisfaction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: CreditCard,
              title: 'Reusable Mifare 1K Credentials',
              desc: 'Issue, wipe, and reuse physical smart cards thousands of times. Zero mechanical lock re-keying costs when cards are lost.',
              color: 'text-zeno-teal',
            },
            {
              icon: Zap,
              title: '12V Fail-Secure Architecture',
              desc: 'Door strikes remain locked during power outages. Powered by a central 12V 5A DC bus with 3.3V step-down buck conversion.',
              color: 'text-amber-500',
            },
            {
              icon: Wifi,
              title: 'Sub-Second Cloud Telemetry',
              desc: 'Every card tap publishes via lightweight MQTT (AWS IoT) to the reception dashboard in 45 milliseconds.',
              color: 'text-blue-500',
            },
            {
              icon: Cpu,
              title: 'Offline Flash Authorization',
              desc: 'ESP32 controllers store active guest room credentials in local flash SPIFFS, ensuring guests enter even if WiFi goes down.',
              color: 'text-emerald-500',
            },
            {
              icon: QrCode,
              title: 'Digital Smartphone QR Backup',
              desc: 'Generate an encrypted digital key link instantly if a guest misplaces their physical blue card at the pool or restaurant.',
              color: 'text-purple-500',
            },
            {
              icon: ShieldCheck,
              title: 'Multi-Role Staff Access',
              desc: 'Tailored views for Administrators (full control), Receptionists (enroll & checkout only), and Technicians (wiring & logs).',
              color: 'text-cyan-500',
            },
          ].map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className={`w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 ${feature.color} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-heading font-black text-lg text-slate-900 dark:text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    {feature.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* EMBEDDED 3-PANEL INTERACTIVE INSTALLATION BLUEPRINT */}
      {/* ========================================================================= */}
      <section id="architecture" className="py-20 px-6 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="text-xs font-bold uppercase tracking-wider text-zeno-teal mb-2">
              Hardware Integration Specifications
            </div>
            <h2 className="text-3xl sm:text-4xl font-heading font-black text-white">
              The 3-Panel Door Controller Architecture
            </h2>
            <p className="text-sm text-slate-400 mt-2">
              Outdoor IP65 RC522 Reader (1.2m height) → Inside Control Cabinet (ESP32 + Relay + 12V Strike) → Cloud & Reception.
            </p>
          </div>

          <InstallationDiagram />
        </div>
      </section>

      {/* ========================================================================= */}
      {/* PRICING & COMMERCIAL PACKAGES */}
      {/* ========================================================================= */}
      <section id="pricing" className="py-20 px-6 max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs font-bold uppercase tracking-wider text-zeno-teal mb-2">
            Turnkey Hotel Deployments
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-black text-slate-900 dark:text-white">
            Transparent Pricing Per Room
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            Hardware kit + custom branded ZENO cards + cloud software subscription.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tier 1: Boutique (10 Rooms) */}
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase text-slate-400">Boutique Hotel</span>
              <h3 className="text-2xl font-heading font-black text-slate-900 dark:text-white mt-1">
                10 Rooms Starter Kit
              </h3>
              <div className="mt-4 mb-6">
                <span className="text-4xl font-heading font-black text-slate-900 dark:text-white">$1,450</span>
                <span className="text-xs text-slate-500 ml-1">turnkey hardware & install</span>
              </div>
              <ul className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
                <li className="flex items-center gap-2">✓ 10x ESP32 + IP65 RC522 Door Controllers</li>
                <li className="flex items-center gap-2">✓ 10x Heavy-Duty 12V Electric Strike Locks</li>
                <li className="flex items-center gap-2">✓ 50x ZENO Blue RFID Smart Cards</li>
                <li className="flex items-center gap-2">✓ 1x Desk USB Reception Enrollment Reader</li>
                <li className="flex items-center gap-2">✓ Full Cloud Dashboard & PWA Tablet App</li>
              </ul>
            </div>
            <Link
              href="/dashboard/invoice"
              className="mt-8 w-full py-3 rounded-xl text-center text-xs font-heading font-black uppercase tracking-wider text-slate-900 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-white transition-colors"
            >
              Generate 10-Room Quote
            </Link>
          </div>

          {/* Tier 2: Premier (25-50 Rooms) Featured */}
          <div className="p-8 rounded-3xl bg-gradient-to-b from-zeno-navy to-slate-900 text-white border-2 border-zeno-teal shadow-glow flex flex-col justify-between relative">
            <span className="absolute -top-3 right-6 bg-zeno-gold text-slate-950 text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow-sm">
              Most Popular
            </span>
            <div>
              <span className="text-xs font-bold uppercase text-zeno-teal">Luxury Resort</span>
              <h3 className="text-2xl font-heading font-black text-white mt-1">
                25 to 50 Rooms Enterprise
              </h3>
              <div className="mt-4 mb-6">
                <span className="text-4xl font-heading font-black text-white">$3,450</span>
                <span className="text-xs text-slate-300 ml-1">full turnkey deployment</span>
              </div>
              <ul className="space-y-3 text-xs text-slate-300">
                <li className="flex items-center gap-2">✓ Up to 50x ESP32 Wireless Door Controllers</li>
                <li className="flex items-center gap-2">✓ 250x Custom Branded ZENO RFID Cards</li>
                <li className="flex items-center gap-2">✓ 2x Desk Reception Enrollment Stations</li>
                <li className="flex items-center gap-2">✓ Dedicated AWS IoT Core Telemetry Broker</li>
                <li className="flex items-center gap-2">✓ 24/7 Priority Engineering Handover & SLA</li>
              </ul>
            </div>
            <Link
              href="/dashboard/invoice"
              className="mt-8 w-full py-3 rounded-xl text-center text-xs font-heading font-black uppercase tracking-wider text-slate-950 bg-gradient-to-r from-zeno-teal to-teal-400 hover:from-teal-300 hover:to-teal-500 shadow-glow transition-all"
            >
              Generate Custom Invoice
            </Link>
          </div>

          {/* Tier 3: Chain / Multi-Property */}
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase text-slate-400">Hotel Chain</span>
              <h3 className="text-2xl font-heading font-black text-slate-900 dark:text-white mt-1">
                Multi-Hotel Network
              </h3>
              <div className="mt-4 mb-6">
                <span className="text-4xl font-heading font-black text-slate-900 dark:text-white">Custom</span>
                <span className="text-xs text-slate-500 ml-1">portfolio discount</span>
              </div>
              <ul className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
                <li className="flex items-center gap-2">✓ Multi-Property Centralized SaaS Portal</li>
                <li className="flex items-center gap-2">✓ Custom ERP / PMS API Integration</li>
                <li className="flex items-center gap-2">✓ White-Label Digital Mobile Guest Key</li>
                <li className="flex items-center gap-2">✓ On-site Technician Certification Program</li>
              </ul>
            </div>
            <Link
              href="/dashboard"
              className="mt-8 w-full py-3 rounded-xl text-center text-xs font-heading font-black uppercase tracking-wider text-slate-900 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-white transition-colors"
            >
              Contact Solutions Team
            </Link>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* FOOTER */}
      {/* ========================================================================= */}
      <footer className="bg-[#090E2D] border-t border-slate-800 text-white py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <ZenoLogo variant="dark" size="sm" showText={true} />
            <p className="text-xs text-slate-400">
              ZENO TECH SOLUTION • Smart Access Systems • 13.56MHz Mifare Classic 1K • ESP32 DevKit
            </p>
          </div>

          <div className="flex items-center gap-6 text-xs text-slate-400 font-semibold">
            <Link href="/dashboard" className="hover:text-zeno-teal">
              Reception Desk
            </Link>
            <Link href="/dashboard/installation" className="hover:text-zeno-teal">
              Firmware (.INO)
            </Link>
            <Link href="/dashboard/invoice" className="hover:text-zeno-teal">
              Quote Calculator
            </Link>
            <Link href="/login" className="hover:text-zeno-teal">
              Staff Portal
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
